#include <iostream>
#include <list>
#include <utility>
using namespace std;
template<typename L>
void selectionsort(L &l)
{
    typename L:: iterator i;
    typename L:: iterator j;
    typename L:: iterator min;
     int moves =0;
    for(i = l.begin();i!=l.end();i++)
    {
        min = i;
        for(j =i;j!=l.end();j++)
        {
            if(*j < *min)
            {
                min = j;
            }
        }
        if(i!=min)
        {
            swap (*i,*min);
            moves = moves +3;
        }
    }
    cout<<"0 copies and "<<moves<<" moves"<<endl;
    
    
}
int main()
{
    list<int> mylist;
    list<int>::iterator it;
   
    mylist.push_back(2);
    mylist.push_back(4);
    mylist.push_back(5);
    mylist.push_back(1);
    mylist.push_back(8);
    mylist.push_back(9);
    cout<<"pre: ";
    cout<<endl;
    for(it = mylist.begin();it!=mylist.end();it++)
    {
        cout<<*it<<" ";
    }
    cout<<endl;
    cout<<"next: ";
    cout<<endl;
    selectionsort(mylist);
    for(it = mylist.begin();it!=mylist.end();it++)
    {
        cout<<*it<<" ";
    }
    cout<<endl;
    
   
    list <pair<int,int>> l2;
    list <pair<int,int>> l;
    list <pair<int,int>> l3;
    list<pair<int,int>>::iterator i;
    l2.push_back(make_pair(1,2));
    l2.push_back(make_pair(3,-1));
    l2.push_back(make_pair(-1,3));
    l2.push_back(make_pair(0,0));
    l2.push_back(make_pair(2,3));
    l2.push_back(make_pair(1,2));
    l2.push_back(make_pair(1,-2));
    l2.push_back(make_pair(8,10));
    cout<<"pre: ";
    cout<<endl;
    for(i = l2.begin();i!=l2.end();i++)
    {
        cout<<"("<<i->first<<","<<i->second<<")";
    }
    cout<<endl;
    cout<<"next: ";
    cout<<endl;
    selectionsort(l2);
    for(i = l2.begin();i!=l2.end();i++)
    {
        cout<<"("<<i->first<<","<<i->second<<")";
    }
    cout<<endl;
    
    
    
    
    
    l.push_back(make_pair(10,2));
    l.push_back(make_pair(-3,-1));
    l.push_back(make_pair(-8,0));
    l.push_back(make_pair(1,1));
    l.push_back(make_pair(1,1));
    l.push_back(make_pair(0,0));
    l.push_back(make_pair(10,2));
    l.push_back(make_pair(5,5));
    l.push_back(make_pair(5,-5));
    l.push_back(make_pair(0,0));
    l.push_back(make_pair(10,2));
    
    cout<<"pre: ";
    cout<<endl;
    for(i = l.begin();i!=l.end();i++)
    {
        cout<<"("<<i->first<<","<<i->second<<")";
    }
    cout<<endl;
    cout<<"next: ";
    cout<<endl;
    selectionsort(l);
    for(i = l.begin();i!=l.end();i++)
    {
        cout<<"("<<i->first<<","<<i->second<<")";
    }
    cout<<endl;
    
    
    
    
    
    l3.push_back(make_pair(-1,3));
    l3.push_back(make_pair(0,0));
    l3.push_back(make_pair(1,-1));
    l3.push_back(make_pair(1,2));
    l3.push_back(make_pair(1,2));
    l3.push_back(make_pair(2,3));
    l3.push_back(make_pair(3,-1));
    l3.push_back(make_pair(8,10));
    
    
    cout<<"pre: ";
    cout<<endl;
    for(i = l3.begin();i!=l3.end();i++)
    {
        cout<<"("<<i->first<<","<<i->second<<")";
    }
    cout<<endl;
    cout<<"next: ";
    cout<<endl;
    selectionsort(l);
    for(i = l3.begin();i!=l3.end();i++)
    {
        cout<<"("<<i->first<<","<<i->second<<")";
    }
    cout<<endl;
    
    
    
}