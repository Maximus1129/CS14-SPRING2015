#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <set>
#include <unordered_set>
#include <ctime> 
using namespace std;

int main(int argc,char* argv[])
{
    clock_t t1;
    clock_t t2;
    clock_t t3;
    clock_t t4;
    vector<string> vec;
    string word;
    ifstream input;
    ofstream output;
    input.open("words.txt");
    
    output.open("data.txt",ios::trunc);
   // cout<<"!1"<<endl;
    while(input>>word)
    {
        vec.push_back(word);
        //cout<<word<<endl;
    }
    //cout<<"!2"<<endl;
    set<string> bst;
    unordered_set<string> htb;
    //cout<<"!3"<<endl;
    for(int n = 5000; n< 50000; n = n+5000)
    {
        //cout<<"!4"<<endl;
        t1 = clock();
        for(int i = 0; i < n; ++i){
            //cout<<"!!"<<endl;
            bst.insert(vec[i]);
        }
        //cout<<"!5"<<endl;
        t1 = clock() - t1;
        
        t2 = clock();
        //cout<<"!6"<<endl;
        for(int i = 0; i < n; ++i){
            bst.find(vec[i]);
        }
        t2 = (clock() - t2);
        
        t3 = clock();
        for(int i = 0; i < n; ++i){
            htb.insert(vec[i]);
        }
        t3 = clock() - t3;
        
        t4 = clock();
        for(int i = 0; i < n; ++i){
            htb.find(vec[i]);
        }
        t4 = (clock() - t4);
        
        output << n << " " << 1000*((float)t1)/CLOCKS_PER_SEC << " " 
                            << 1000*((float)t3)/CLOCKS_PER_SEC << " " 
                            << 1000*((float)t2)/CLOCKS_PER_SEC/n << " " 
                            << 1000*((float)t4)/CLOCKS_PER_SEC/n << endl;
        bst.clear();
        htb.clear();
    }
    //cout<<"!4"<<endl;
    output.close();
    return 0;

       
}