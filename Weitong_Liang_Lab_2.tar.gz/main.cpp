#include <iostream>
#include <string>
#include <cstring>
#include <forward_list>
using namespace std;
template <typename Type>
struct Node
{
    Type value;
    Node<Type>* next;
    Node<Type>(Type value):value(value),next(0)
    {}
    
    
};
template <typename Type>
class List
{
private:
    Node<Type>* head;
    Node<Type>* tail;
public:
    List()
    {
        //cout<<"1"<<endl;
        head = 0;
        tail = 0;
    }
    ~List()
    {
        // cout<<"@"<<endl;
        //  cout<<tail->value;
        // cout<<"head"<<head->value;
        while(head!=0)
        {
            //cout<<"POP"<<endl;
            pop_front();
        }
    }
    void pop_front()
    {
        if (head == 0) return;
        Node<Type> *temp = head;
        head = head->next;
        delete temp;
        
    }
    void push_back(Type value)
    {
        if(head==0)
        {
            Node<Type>* temp;
            temp = new Node<Type>(value);
            head = temp;
            tail = temp;
            temp->next = 0;
            
        }
        else
        {
            Node<Type>* temp;
            temp = new Node<Type>(value);
            tail->next = temp;
            temp->next =0;
            tail = temp;
            
        }
    }
    void print()
    {
        Node<Type>* curr;
        for(curr = head;curr!= tail;curr = curr->next)
        {
            cout<<curr->value;
        }
        cout<<curr->value;
    }
    int size()
    {
        int sz =0;
        if(head==0)
        {
            return 0;
        }
        for(Node<Type>* curr = head;curr!= tail;curr = curr->next)
        {
            sz =sz +1;
        }
        return sz+1;
    }
    void elmentSwap(int pos)
    {
        if(pos>=size()-1 || pos<0 ||(pos==0 && size()==1))
        {
            cout<<"Out of range!"<<endl;
        }
        else
        {
            if(pos==0)
            {
                Node<Type>* temp;
                Node<Type>* tmp;//pos+2
                temp = head;
                tmp = head->next->next;
                head = head->next;
                head->next = temp;
                temp->next = tmp;
                if(head == tail)
                {
                    tail = head->next;
                    tail->next =0;
                }
            }
            else
            {
                int count=0;
                Node<Type>* temp;//pos
                Node<Type>* tmp;//pos+2
                Node<Type>* curr;//pos-1
                curr = head;
                if(pos==1)
                {
                    curr = head;
                }
                else
                {
                    do
                    {
                        //cout<<"curr1"<<curr->value<<endl;
                        count++;
                        curr = curr->next;
                        }while(count<pos-1);
                }
                temp = curr->next;
                cout<<"head"<<head->value<<endl;
                cout<<"curr"<<curr->value<<endl;
                cout<<"temp"<<temp->value<<endl;
                cout<<"temp->next"<<temp->next->value<<endl;
                  
                tmp = temp->next->next;
                curr->next = temp->next;
                temp->next->next = temp;
                temp->next =tmp;
                if(tmp==0)
                {
                    cout<<"?"<<endl;
                    tail = temp;
                    tail->next =0;
                }
            }
        }
    }
};

template <typename Type>
forward_list <Type> listCopy( forward_list <Type> L, forward_list<Type>& P )
{
    typename forward_list<Type>::iterator i;
    forward_list<Type> temp;
    int  j =0;
    temp = L;
    temp.reverse();
    int num = 0;
    for(i = P.begin();i!=P.end();++i)
    {
        num = num+1;
    }
    const int number = num;
    Type arr[number];
    for(i = P.begin();i!=P.end();++i)
    {
        arr[j] = *i;
        //cout<<"?"<<j<<" "<<arr[j]<<endl;
        ++j;
        //cout<<j<<endl;
    }
    //    cout<<j<<endl;
    //arr[j] = *i;
    for(j =number-1;j>0;j--)
    {
        temp.insert_after(temp.before_begin(),arr[j]);
        cout<<"!"<<temp.front()<<endl;
    }
    temp.insert_after(temp.before_begin(),arr[0]);
    P = temp;
    return P;
    
}
template <typename Type>
void printLots (forward_list <Type> L, forward_list <int> P)
{
    unsigned long num = P.max_size();
    forward_list<int>::iterator j;
    typename forward_list<Type>::iterator k;
    j = P.begin();
    k = L.begin();
    for(unsigned long i =0;i<num;i++)
    {
        int value = *j;
        int a =0;
        if(value==0)
        {
            cout<<L.front();
        }
        else
        {
            do
            {
                ++k;
                if(k==L.end())
                {
                    cout<<"Out of range!"<<endl;
                    break;
                }
                ++a;
                
            }while(a<value);
            if(k==L.end())
            {
                break;
            }
            cout<<*k;
        }
        k = L.begin();
        ++j;
        if(j==P.end())
        {
            break;
        }
    }
    
}
bool isPrime( int i )
{
    if(i==1)
    {
        return false;
    }
    if(i==2)
    {
        return true;
    }
    else
    {
        int num = 0;
        for(num=2;num <i;++num)
        {
            if(i%num==0)
            {
                return false;
            }
        }
        return true;
    }
}
int primeCount(forward_list<int> lst)
{
    if(lst.empty())
    {
        cout<<"!"<<endl;
        return 0;
    }
    else
    {
        if(isPrime(*lst.begin()))
        {
            cout<<*lst.begin();
            lst.pop_front();
            return 1+primeCount(lst);
        }
        //cout<<"!"<<endl;
        lst.pop_front();
        return 0+primeCount(lst);
    }
}






int main()
{
//        cout<<"!"<<endl;
//    forward_list<char> x;
//        forward_list<char>p;
//        forward_list<char>::iterator j;
//        p.push_front('z');
//        p.push_front('y');
//        p.push_front('x');
//    x.push_front('a');
//    x.push_front('b');
//        x.push_front('c');
//        x.push_front('e');
//        x.push_front('f');
    //    x.push_front('g');
    //    x.push_front('h');
    //    x.push_front('i');
    //    x.push_front('j');
    //    x.push_front('k');
    //
//       p=listCopy(x,p);
//    -------------test for function primeCount and listcopy---------------
//        cout<<"THe number is :"<<primeCount(x)<<endl;
//        for(j=p.begin();j!=p.end();++j)
//        {
//            cout<<*j;
//    
//        }
    //______________________________________________________________________
    
    
    
    
    //---------------------test for printlots---------------------------
//    forward_list <char> L;
//    forward_list<int> x;
//        L.push_front('k');
//        L.push_front('j');
//        L.push_front('i');
//        L.push_front('h');
//        L.push_front('g');
//        L.push_front('f');
//        L.push_front('e');
//        L.push_front('d');
//        L.push_front('c');
//    x.push_front(1);
//    L.push_front('b');
//    L.push_front('a');
//    printLots(L, x);
    
    
    
    //____________________________________________________________________
    
    //---------------------test swap--------------------------

    List<int> L;
    L.push_back(1);
    L.push_back(2);
     L.push_back(3);
     L.push_back(4);
     L.push_back(5);
     L.print();
    L.elmentSwap(4);
    L.print();

    
    
    //____________________________________________________________________
    
    return 0;
}