#include "Lab3.h"
#include <iostream>
#include <array>
#include <stdlib.h>
#include <stack>
#include <cstring>
using namespace std;

void print(int number,char A,char B,char C)
{
    if(number>0)
    {
        print(number-1,A,C,B);
        cout<<"Moved "<<number<<" from peg "<<A<<" to peg "<<C<<endl;
        print(number-1,B,A,C);
    }
}

template<typename T>
void showTowerStates(int number, stack<T>& A,stack<T>& B, stack<T>& C)
{
    T temp;
    
    if(number == 1)
    {
        temp = A.top();
        A.pop();
        C.push(temp);
    }
    // else if(number == 2)
    // {
    //     temp = A.top();
    //     A.pop();
    //     B.push(temp);
        
    //     temp = A.top();
    //     A.pop();
    //     C.push(temp);
        
    //     temp = B.top();
    //     B.pop();
    //     C.push(temp);
    // }
    // else if(number == 3)
    // {
    //     temp = A.top();
    //     A.pop();
    //     C.push(temp);
    //     //1->c
    //     temp = A.top();
    //     A.pop();
    //     B.push(temp);//2->B
        
    //     temp = C.top();
    //     C.pop();
    //     B.push(temp);//1->B
        
    //     temp = A.top();
    //     A.pop();
    //     C.push(temp);//3->c
        
    //     temp = B.top();
    //     B.pop();
    //     A.push(temp);//1->a
        
    //     temp = B.top();
    //     B.pop();
    //     C.push(temp);//2->c
        
    //     temp = A.top();
    //     A.pop();
    //     C.push(temp);//1->c
    // }
    else
    {
        showTowerStates(number - 1, A, C, B);
        
         
        temp = A.top();
        A.pop();
        C.push(temp);
        
        showTowerStates(number - 1, B, A, C);

         
    }
    

}
  
int main()
{
//--------------------test Lab3_1----------------------------------------------------    
//--------------------test funtion isEmptyStack and topstack-------------------------    
    // TwoStackFixed<int> X(10,3);
    // cout<<"if the A empty?"<<X.isEmptyA()<<endl;
    // cout<<"if the B empty?"<<X.isEmptyB()<<endl;
    // X.pushA(1);
    // X.pushB(11);
    // cout<<"if the A empty?"<<X.isEmptyA()<<endl;
    // cout<<"if the B empty?"<<X.isEmptyB()<<endl;
    // cout<<X.topA()<<endl;
    // cout<<X.topB()<<endl;
    // cout<<X.topA()<<endl;

//-------------------test funciton isfullStack-------------------------
    // TwoStackFixed<int> X(10,3);
    // cout<<"Is A full?"<<X.isFullA()<<endl;
    // cout<<"Is A full?"<<X.isFullB()<<endl;
    // X.pushA(1);
    // X.pushA(2);
    // X.pushA(3);
    // cout<<"Is A full?"<<X.isFullA()<<endl;
    // X.pushB(11);
    // X.pushB(12);
    // X.pushB(13);
    // X.pushB(14);
    // X.pushB(15);
    // X.pushB(16);
    // X.pushB(17);
    // cout<<"Is A full?"<<X.isFullB()<<endl;
    

//--------------------test Lab3_2----------------------------------------------------
    // TwoStackOptimal<int>y(10);
    
    // cout<<"if the A empty?"<<y.isEmptyA()<<endl;
    // cout<<"if the B empty?"<<y.isEmptyB()<<endl;
    // y.pushFlexA(1);
    // y.pushFlexB(11);
    // cout<<"if the A empty?"<<y.isEmptyA()<<endl;
    // cout<<"if the B empty?"<<y.isEmptyB()<<endl;
    // cout<<y.topFlexA()<<endl;
    // cout<<y.topFlexB()<<endl;

    // cout<<"if the A empty?"<<y.isEmptyA()<<endl;
    // cout<<"if the B empty?"<<y.isEmptyB()<<endl;
    // y.pushFlexA(1);
    // y.pushFlexA(2);
    // y.pushFlexA(3);
    // y.pushFlexA(4);
    // y.pushFlexB(5);
    // y.pushFlexB(6);
    // y.pushFlexB(7);
    // y.pushFlexB(8);
    // y.pushFlexB(9);
    // cout<<"if the A full?"<<y.isFullA()<<endl;
    // cout<<"if the B full?"<<y.isFullB()<<endl;
    // y.pushFlexA(10);
    // cout<<"if the A full?"<<y.isFullA()<<endl;
    // cout<<"if the B full?"<<y.isFullB()<<endl;
   int i, num, ele;
    
    cout << "Welcome to Tower of Hanoi\n\n" ;
    cout << "Enter height of Tower:\n" ;
    cin >> num ;
    
    stack<int> A;
    stack<int> B;
    stack<int> C;
    
    cout << "\nEnter your numbers in descending order:\n\n" ;
    for(i = 0; i < num; i++)
    {
        cout << "Enter " << i+1 << " Element\n" ;
        cin >> ele ;
        A.push(ele);        
    }
    showTowerStates(num, A, B, C);
    print(num,'A','B','C');
    // do
    // {
    //     cout<<C.top();
    //     C.pop();
    // }while(!C.empty());
    
    return 0;
}