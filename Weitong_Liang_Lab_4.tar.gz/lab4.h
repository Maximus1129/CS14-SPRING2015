//  =============== BEGIN ASSESSMENT HEADER ================
/// @file cs-homework/CS 014/Lab/main.cpp
/// @brief Lab <4> for CS 14 <Spring & 2015>
///
/// @author <Weitong Liang> [weitongliang11@gmail.com]
/// @date <5/4/2015>
///
/// @par Enrollment Notes
///     Lecture Section: <001>
/// @par
///     Lab Section: <023>
/// @par
///     TA: <Dingwen Tao>
///
/// @par Plagiarism Section
/// I hereby certify that the code in this file
/// is ENTIRELY my own original work.
//  ================== END ASSESSMENT HEADER ===============

#include <iostream>

#include <utility>
#include<vector>
#include<algorithm>
using namespace std;

typedef pair<int,int> Entry;
class priority_queue {
public:
  vector<Entry> entries;
  Entry& front() { return entries.back(); }
  void pop() { entries.pop_back(); }
  void push( Entry e ) {
    entries.push_back( e );
    for ( int i = entries.size()-1; i != 0; --i ) {
      if ( (entries[i].first + entries[i].second) < (entries[i-1].first + entries[i-1].second) ) break;
      swap(entries[i], entries[i-1]);
    }
  }
};

void sort_Coprimes(int m, int n, int k, priority_queue &coprimes) {
    if ((m + n) > k) {
        return;
    }
    Entry tmp(m, n);
    coprimes.push(tmp);
    sort_Coprimes((2*m - n), m, k, coprimes);
    sort_Coprimes((2*m + n), m, k, coprimes);
    sort_Coprimes((m + 2*n), n, k, coprimes);
}

void sortOrder(int k) {
    priority_queue coprimes;
    sort_Coprimes(2, 1, k, coprimes);
    sort_Coprimes(3, 1, k, coprimes);
    Entry tmp;
    cout << "Sorted:" << endl;
    while (!coprimes.entries.empty()) {
        tmp = coprimes.front();
        cout << tmp.first << " " << tmp.second << endl;
        coprimes.pop();
    }
}
// typedef pair <int,int> p;
// void pushpreoder(int m,int n, int k,priority_queue<pair<int,int>>& pq)
// {
//     pair<int,int> p1;
//     if ((m + n) >k) return;
//     p1.first = m;
//     p1.second = n;
//     pq.push(p1);
//     pushpreoder(2*m - n, m, k,pq);
//     pushpreoder(2*m + n, m, k,pq);
//     pushpreoder(m + 2*n, n, k,pq);
// }
// void pushprint(priority_queue<pair<int,int>>& pq)
// {
//     pair<int,int> p1;
//     if(pq.empty())
//     {
//         return;
//     }
//     else
//     {
//         p1 = pq.top();
//         pq.pop();
//         pushprint(pq);
//         cout<<p1.first<<" "<<p1.second<<endl;
//     }
// }
// void push(int k)
// {
//     pair<int,int> p;
//     priority_queue<pair<int,int>> pq;
//     pushpreoder(2,1,k,pq);
//     pushpreoder(3,1,k,pq);
//     pushprint(pq);
// }









void preordersub(int m, int n, int k)
{
    if ((m + n) >k) 
    return;
    cout << m << " " << n << endl;
    preordersub(2*m - n, m, k);
    preordersub(2*m + n, m, k);
    preordersub(m + 2*n, n, k);
}
void preorder(int k)
{
    preordersub(2,1,k);
    preordersub(3,1,k);
}

void postordersub(int m, int n, int k)
{
    if ((m + n) > k) return;
    postordersub(2*m - n, m, k);
    postordersub(2*m + n, m, k);
    postordersub(m + 2*n, n, k);
    cout << m << " " << n << endl;
}
void postorder(int k)
{
    postordersub(2,1,k);
    postordersub(3,1,k);
}
