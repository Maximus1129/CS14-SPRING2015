1.
As we could see from the plot, the Hash table has 
better performance than binary self-balancing tree considering the 
situation of inserting or finding data.

2.
Hash table is really good at dealing large number of data.

3.
Hash table is not very good at ordering since it just insert
one and another data into the Hash table. For self-balancing tree,
for sure it has better order.
