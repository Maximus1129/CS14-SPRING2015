//  =============== BEGIN ASSESSMENT HEADER ================
/// @file cs-homework/CS 014/Lab/main.cpp
/// @brief Lab <4> for CS 14 <Spring & 2015>
///
/// @author <Weitong Liang> [weitongliang11@gmail.com]
/// @date <5/4/2015>
///
/// @par Enrollment Notes
///     Lecture Section: <001>
/// @par
///     Lab Section: <023>
/// @par
///     TA: <Dingwen Tao>
///
/// @par Plagiarism Section
/// I hereby certify that the code in this file
/// is ENTIRELY my own original work.
//  ================== END ASSESSMENT HEADER ===============
#include "lab4.h"
#include <iostream>

#include <utility>
#include<vector>
#include<algorithm>
using namespace std;

int main(int argc, char *argv[])
{
    if ( argc != 2 ) {
        cout << "Please input: ./a.out n"<<endl;
        exit(-1);
    }
//----------- test for preorder------------ 
    cout<<"preorder:"<<endl;
    int i = atoi(argv[1]);
    preorder(i);


//---------- test for postorder------------
    cout<<"postorder:"<<endl;
    int j = atoi(argv[1]);
    postorder(j);


//---------test for in order----------------
    int k = atoi(argv[1]);
    sortOrder(k);
    return 0;
}