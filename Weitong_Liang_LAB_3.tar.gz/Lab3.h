#include <iostream>
#include <array>
#include <stdlib.h>
using namespace std;

template<typename T>
class TwoStackFixed
{
    private:
    T* arr;
    int size1;
    int size2;
    int size;
    int curr1;
    int curr2;
    
    public:
    TwoStackFixed(int size, int maxtop )
    {
        arr = new T(size);
        size1 = maxtop;
        size2 = size - size1;
        curr1 = -1;
        curr2 = size;
        this->size = size;
    }
    void pushStack1(T value)
    {
        curr1 = curr1+1;
        if(curr1>size1-1)
        {
            curr1 = curr1-1;//to stay at the maxtop position!
            cout<<"Out of Stack1's range!";
        }
        else
        {
            arr[curr1] = value;
        }
    }
    
    void pushStack2(T value)
    {
        curr2 = curr2-1;
        if(curr2<size1)
        {
            curr2 =size1;
            cout<<"Out of Stack2's range!";
        }
        else
        {
            arr[curr2] = value;
        }
        
    }
    T popStack1()
    {
        if(isEmptyStack1())
        {
            cout<<"Out of range, can not pop!"<<endl;
            exit(EXIT_FAILURE);
        }
        else
        {
            T value;
            value = arr[curr1];
            curr1 = curr1 -1;
            return value;
        }
    }
    T popStack2()
    {
        if(isEmptyStack2())
        {
            cout<<"Out of range, can not pop!"<<endl;
            exit(EXIT_FAILURE);
        }
        else
        {
            T value;
            value = arr[curr2];
            curr2 = curr2 +1;
            return value;
        }
    }
    bool isFullStack1()
    {
        if(curr1 ==size1-1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
     bool isFullStack2()
    {
        if(curr2 ==size1)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool isEmptyStack1()
    {
        if(curr1 ==-1 )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool isEmptyStack2()
    {
        if(curr2==size )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
};

template<typename T>
class TwoStackOptimal
{
    private:
    T* arr;
    int size;
    int curr1;
    int curr2;
    
    public:
    TwoStackOptimal(int size)
    {
        arr = new T(size);
        curr1 = -1;
        curr2 = size;
        this->size = size;
    }
    void pushFlexStack1(T value)
    {
        curr1 = curr1+1;
        if(curr1==curr2)
        {
            curr1 = curr1-1;//to stay at the maxtop position!
            cout<<"Out of Stack1's range!";
        }
        else
        {
            arr[curr1] = value;
        }
    }
    
    void pushFlexStack2(T value)
    {
        curr2 = curr2-1;
        if(curr2==curr1)
        {
            curr2 = curr2-1;
            cout<<"Out of Stack2's range!";
        }
        else
        {
            arr[curr2] = value;
        }
    }
    T popFlexStack1()
    {
        if(isEmptyStack1())
        {
            cout<<"Out of range, can not pop!"<<endl;
            exit(EXIT_FAILURE);
        }
        else
        {
            T value;
            value = arr[curr1];
            curr1 = curr1 -1;
            return value;
        }
    }
    T popFlexStack2()
    {
        if(isEmptyStack2())
        {
            cout<<"Out of range, can not pop!"<<endl;
            exit(EXIT_FAILURE);
        }
        else
        {
            T value;
            value = arr[curr2];
            curr2 = curr2 +1;
            return value;
        }
    }
    bool isFullStack1()
    {
        if((curr1+1)+(size-curr2) == size)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
     bool isFullStack2()
    {
        if((curr1+1)+(size-curr2) == size)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool isEmptyStack1()
    {
        if(curr1 ==-1 )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    bool isEmptyStack2()
    {
        if(curr2==size )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
};