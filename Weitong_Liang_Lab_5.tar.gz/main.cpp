#include <cassert>
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <sstream>
#include <map>
#include <list>
#include <math.h>
#include <vector>
#include <stdlib.h>
using namespace std;
#define nil 0
// #define Value int // restore for testing.
template < typename Value >

class BST 
{
    class Node 
    { // binary tree node
        public:
        Node* left;
        Node* right;
        Value value;
        Node( const Value v)
        {
            value = v;
            left = nil;
            right = nil;
        }
        // : value(v), left(nil), right(nil)
        // {}
        Value& content() { return value; }
        bool isInternal() { return left != nil && right != nil; }
        bool isExternal() { return left != nil || right != nil; }
        bool isLeaf() { return left == nil && right == nil; }
        int height() 
        {
            if(this == nil)
            {
                return -1;
            }
            if(isLeaf())
            {
               return 0;
            }
            else
            {
                return max(this->left->height(),this->right->height())+1;
            }
            // returns the height of the subtree rooted at this node
                                                                        // FILL IN
        }
        int size() 
        {
            if(this ==nil)
            {
                return -1;
            }
            else if(isLeaf())
            {
                return 1; 
            }
            else
            {
                return 1 + this->left->size() + this->right->size();
            }
            // returns the size of the subtree rooted at this node,
            // FILL IN
        }
    }; // Node
// const Node* nil; // later nil will point to a sentinel node.
    Node* root;
    int count;
    Value x;
    public:
    int size() 
    {
        // cout<<"root";
        // print_node(root);
        // cout<<endl;
        // cout<<"9";
        // print_node(root->right);
        // cout<<endl;
        // cout<<"5";
        // print_node(root->left);
        // cout<<endl;
        // cout<<"2";
        // print_node(root->left->left);
        // cout<<endl;
        // cout<<"4";
        // print_node(root->left->left->right);
        // cout<<endl;
        // cout<<"1";
        // print_node(root->left->left->left);
        // cout<<endl;
        return size(root);
        // size of the overall tree.
        // FILL IN
    }
    int size(Node* n)
    {
        if( n ==nil)
            {
                return 0;
            }
            else if(root->left ==nil && root->right ==nil)
            {
                return 1; 
            }
            else
            {
                return 1 + size(n->left) + size(n->right);
            }
    }
    bool empty() { return size() == 0; }
    void print_node( const Node* n ) 
    {
        if(n ==nil)
        {
            cout<<"Empty!"<<endl;
        }
        else
        {
            cout<< n->value<<endl;
        }
        // Print the node’s value.
        // FILL IN
    }
    bool search ( Value x ) 
    {
        return search (x,root);
        // search for a Value in the BST and return true iff it was found.
        // FILL IN
    }
    bool search(Value x, Node* n)
    {
        if(n == nil)
        {
            return false;
        }
        else if(x < n->value)
        {
            return search(x,n->left);
        }
        else if(x > n->value)
        {
            return search(x,n->right);
        }
        else
        {
            return true;
        }
    }
    void preorder()const 
    {
        preorder(root);
        
        // Traverse and print the tree one Value per line in preorder.
        // FILL IN
    }
    void preorder(Node* n)const
    {
        if(n == nil)
        {
            return;
        }
        cout<<n->value<<" ";
        preorder(n->left);
        preorder(n->right);
        
        
    }
    void postorder()const 
    {
        postorder(root);
        // Traverse and print the tree one Value per line in postorder.
        // FILL IN
    }
    void postorder(Node* n)const
    {
        if(n == nil)
        {
            return;
        }
        postorder(n->left);
        postorder(n->right);
        cout<<n->value<<" ";
    }
    void inorder()const 
    {
        
        inorder(root);
        
        // Traverse and print the tree one Value per line in inorder.
        // FILL IN
    }
    void inorder(Node* n)const
    {
        if(n == nil)
        {
            return;
        }
        inorder(n->left);
        cout<<n->value<<" ";
        inorder(n->right);
        
    }
   
    
    void inorderfind(Node* n,vector<Value>& vec)
    {
        Value val;
        if(n == nil)
        {
            return;
        }
        inorderfind(n->left,vec);
        val = n->value;
        //cout<<"!!"<<val<<" ";
        vec.push_back(val);
        inorderfind(n->right,vec);
        
    }
    Value& operator[] (int n) 
    {
        vector<Value> vec;
        if(n >size() && n<0)
        {
            cout<<"Out of range!"<<endl;
            exit (EXIT_FAILURE);
        }
        
        
        inorderfind(root,vec);
        x = vec.at(n);
        
        return x;
    }
    
        // returns reference to the value field of the n-th Node.
        // FILL IN
    
    
    //: count(0), root(nil)
    BST() 
    {
        count = 0;
        root = nil;
    }
    void insert( Value X ) { root = insert( X, root ); }
    Node* insert( Value X, Node* T ) 
    {
        // The normal binary-tree insertion procedure ...
        if ( T == nil ) {
        T = new Node( X ); // the only place that T gets updated.
        } 
        else if ( X < T->value ) 
        {
            T->left = insert( X, T->left );
        } 
            else if ( X > T->value ) 
            {
                T->right = insert( X, T->right );
            } 
            else 
            {
                T->value = X;
            }
            // later, rebalancing code will be installed here
            return T;
    }
    void remove( Value X ) { root = remove( X, root ); }
    Node* remove( Value X, Node*& T ) 
    {
            // The normal binary-tree removal procedure ...
            // Weiss’s code is faster but way more intricate.
        if ( T != nil ) 
        {
            if ( X > T->value ) 
            {
                T->right = remove( X, T->right );
            } 
            else if ( X < T->value ) 
            {
                T->left = remove( X, T->left );
            }   
            else 
            { // X == T->value
                if ( T->right != nil ) 
                {
                    Node* x = T->right;
                    while ( x->left != nil )
                    {
                        x = x->left;
                    }
                T->value = x->value; // successor’s value
                T->right = remove( T->value, T->right );
                } 
                else if ( T->left != nil ) 
                {
                    Node* x = T->left;
                    while ( x->right != nil ) x = x->right;
                    T->value = x->value; // predecessor’s value
                    T->left = remove( T->value, T->left );
                } 
                else 
                { // *T is external
                    delete T;
                    T = nil; // the only updating of T
                }
            }
        }
        // later, rebalancing code will be installed here
    return T;
    }
    void okay( ) { okay( root ); }
    void okay( Node* T ) 
    {
        // diagnostic code can be installed here
        return;
    }
    void displayMinCover()
    {
       
    
        minCoverhelp(root);
        cout<<endl;
        cout<<minCoverhelpnumber(root);
        cout<<endl;
        
        
    }
    int minCoverhelpnumber(Node* n)
    {
       if(n == nil)
        {
            return 0;
        }
        else 
        //((n->left!=nil || n->right!=nil ) && ( n!=root))
        {
            return 1+minCoverhelpnumber(n->left);
            return 1+minCoverhelpnumber(n->right);
        }
        
    }
    
    void minCoverhelp(Node* n)
    {
        if(n == nil)
        {
            return;
        }
        minCoverhelp(n->left);
        if((n->left!=nil || n->right!=nil ) && ( n!=root))
        {
            cout<<n->value<<" ";
        }
        minCoverhelp(n->right);
    }
}; // BST

int main()
{
    
    BST<int> mytree;
    mytree.insert(50);
    mytree.insert(20);
    mytree.insert(60);
    mytree.insert(10);
    mytree.insert(15);
    mytree.insert(25);
    mytree.insert(70);
    mytree.insert(55);
    cout<<"Part1\n";
    mytree.displayMinCover();
   
    // cout<<"is is empty?"<<mytree.empty()<<endl;
    // mytree.preorder();
    // cout<<endl;
    // mytree.postorder();
    // cout<<endl;
    // mytree.inorder();
    // cout<<endl;
    
    // //search
    // cout<< mytree.size()<<endl;
    
    // //operator[]
    // cout<<"operator";
    // cout<<mytree[10]<<endl;
    
}